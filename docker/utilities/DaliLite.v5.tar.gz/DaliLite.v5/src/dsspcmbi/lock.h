#ifndef _lock_h_
#define _lock_h_

#if __GNUG__ >= 2
#  pragma interface
#endif

int HasLicense();
char* GetLicenseString();

#endif
